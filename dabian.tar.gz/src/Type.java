

public abstract class Type extends AST{
    @Override public boolean Round2(){
        return true;
    }

    public boolean equal(Type type){
        return true;
    }
}
