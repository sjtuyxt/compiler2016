

public abstract class Decl extends AST{
}
