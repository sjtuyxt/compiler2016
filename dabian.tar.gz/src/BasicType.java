

public abstract class BasicType extends Type {
}
