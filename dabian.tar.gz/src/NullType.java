
public class NullType extends Type{
}
