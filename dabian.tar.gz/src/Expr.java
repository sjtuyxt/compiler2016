

public abstract class Expr extends Stmt {
    public boolean IsLeft(){
        return false;
    }
}
