

public class VoidType extends BasicType {
}
