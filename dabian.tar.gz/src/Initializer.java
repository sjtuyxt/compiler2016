

public abstract class Initializer {
}
