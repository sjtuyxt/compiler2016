

import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;

public class Program extends AST{
	public static List<AST> list = new ArrayList<AST>();
}