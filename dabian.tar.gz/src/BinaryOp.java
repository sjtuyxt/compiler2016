

public enum BinaryOp {
    ASSIGN,

    LOGICAL_OR, LOGICAL_AND, OR, XOR, AND, EQ, NE, LT, GT, LE, GE, SHL, SHR, ADD, SUB,
    MUL, DIV, MOD
}
