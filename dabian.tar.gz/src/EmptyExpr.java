

public class EmptyExpr extends Expr {
}
