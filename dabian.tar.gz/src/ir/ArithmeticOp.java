package ir;

public enum ArithmeticOp {
    ADD, SUB, MUL, DIV, MOD, SHL, SHR, AND, OR, XOR,

    MINUS, TILDE
}
