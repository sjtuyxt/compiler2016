package ir;

public abstract class Address extends Quadruple{
}
