package ir;

import java.io.PrintStream;

public class Temp extends Address {
    public static int tempCount = 0;

    public int num;

    public Temp() {
        num = tempCount++;
    }

    public void out(PrintStream x){
        x.print("$");
        x.print(num);
        x.print(" ");
    };

    @Override public String generate(){
        String s = Register.get(num);
        return s;
    }
}
