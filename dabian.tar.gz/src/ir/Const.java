package ir;

public abstract class Const extends Address {
}
