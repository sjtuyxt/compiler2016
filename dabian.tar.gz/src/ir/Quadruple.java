package ir;

import java.io.PrintStream;

public abstract class Quadruple {
    public void out(PrintStream x){};
    public String generate(){
        return null;
    };
}
