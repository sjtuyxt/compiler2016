package ir;

/**
 * Created by xiaotian on 2016/5/7.
 */
public class Mips {
    static public String s = "";
}
