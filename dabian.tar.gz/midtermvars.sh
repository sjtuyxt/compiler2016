export CCHK="java -classpath ../src/antlr-4.5.2-complete.jar:../bin mo"
